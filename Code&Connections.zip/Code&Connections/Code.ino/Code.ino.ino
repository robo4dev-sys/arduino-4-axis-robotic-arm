#include <Servo.h>

// Define Servo Objects for the 4-axis arm + 1 gripper
Servo servo1; // Base
Servo servo2; // Shoulder
Servo servo3; // Elbow
Servo servo4; // Wrist
Servo servo5; // Gripper

// Input Pins
const int joy1X = A0; 
const int joy1Y = A1;
const int joy2X = A2;
const int joy2Y = A3;
const int joyBtn = 2; // Integrated joystick button

bool servo5Pos = false; 
int lastBtnState = HIGH;

void setup() {
  // Attaching to PWM-capable pins on the Mega
  servo1.attach(3);
  servo2.attach(5);
  servo3.attach(6);
  servo4.attach(9);
  servo5.attach(10);

  pinMode(joyBtn, INPUT_PULLUP); // Use internal pull-up resistor
  servo5.write(0);               // Initialize gripper to closed/open
}

void loop() {
  // EXECUTION: Read joystick and update 4 axes immediately
  servo1.write(map(analogRead(joy1X), 0, 1023, 0, 180));
  servo2.write(map(analogRead(joy1Y), 0, 1023, 0, 180));
  servo3.write(map(analogRead(joy2X), 0, 1023, 0, 180));
  servo4.write(map(analogRead(joy2Y), 0, 1023, 0, 180));

  // EXECUTION: Edge detection for the Gripper Button
  int currentBtnState = digitalRead(joyBtn);
  if (currentBtnState == LOW && lastBtnState == HIGH) {
    servo5Pos = !servo5Pos; 
    servo5.write(servo5Pos ? 90 : 0);
    delay(200); // Software debouncing
  }
  
  lastBtnState = currentBtnState;
  delay(15); // Refresh rate for servo stability
}